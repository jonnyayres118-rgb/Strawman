import { DEFAULT_ASSUMPTIONS, MARGIN_WARNING_THRESHOLD } from "./constants";
import type { CommercialAssumptions, CommercialRole } from "./types";

export interface RoleEconomics { trueBuyRate: number; sellRate: number; gpPerDay: number; grossMargin: number; markup: number; monthlyBuy: number; monthlyRevenue: number; totalBuy: number; totalRevenue: number; totalGp: number; warning?: string }
export interface TeamEconomics { rows: Array<{ role: CommercialRole; economics: RoleEconomics }>; headcount: number; monthlyBuy: number; monthlyRevenue: number; totalBuy: number; totalRevenue: number; totalGp: number; grossMargin: number; warningCount: number }

export function trueBuyRate(role: CommercialRole, assumptions: CommercialAssumptions = DEFAULT_ASSUMPTIONS): number {
  if (role.buyRate > 0) return role.buyRate;
  if (role.engagementType === "employee" && role.salaryBenchmark) {
    const annual = role.salaryBenchmark * (1 + assumptions.employerOnCostsPct + assumptions.recruitmentPct + assumptions.managementPct + assumptions.benchPct) + assumptions.equipmentAnnual + assumptions.softwareMonthly * 12;
    return annual / assumptions.employeeWorkingDays;
  }
  const eorDaily = role.engagementType === "contractor" ? assumptions.eorMonthly / assumptions.billableDaysPerMonth : 0;
  return role.benchmarkRate + eorDaily + (role.deliveryOverheadPerDay ?? 0);
}

export function calculateRoleEconomics(role: CommercialRole, assumptions: CommercialAssumptions = DEFAULT_ASSUMPTIONS): RoleEconomics {
  const buy = trueBuyRate(role, assumptions);
  const targetMargin = role.targetMargin ?? assumptions.targetMargin;
  const sell = role.pricingMode === "manual" ? (role.sellRate || 0) : role.pricingMode === "markup" ? buy * (1 + (role.targetMarkup ?? 0.6)) : buy / Math.max(0.01, 1 - targetMargin);
  const gp = sell - buy; const margin = sell ? gp / sell : 0; const markup = buy ? gp / buy : 0;
  const days = assumptions.billableDaysPerMonth * role.allocation; const months = role.durationMonths;
  return { trueBuyRate: buy, sellRate: sell, gpPerDay: gp, grossMargin: margin, markup, monthlyBuy: buy * days, monthlyRevenue: sell * days, totalBuy: buy * days * months, totalRevenue: sell * days * months, totalGp: gp * days * months, warning: margin < MARGIN_WARNING_THRESHOLD ? `Margin ${(margin * 100).toFixed(1)}% is below Elastic's 35% threshold.` : undefined };
}

export function calculateTeamEconomics(roles: CommercialRole[], assumptions: CommercialAssumptions = DEFAULT_ASSUMPTIONS): TeamEconomics {
  const rows = roles.map((role) => ({ role, economics: calculateRoleEconomics(role, assumptions) }));
  const sum = (key: "monthlyBuy" | "monthlyRevenue" | "totalBuy" | "totalRevenue" | "totalGp") => rows.reduce((total, row) => total + row.economics[key], 0);
  const totalRevenue = sum("totalRevenue"); const totalGp = sum("totalGp");
  return { rows, headcount: roles.length, monthlyBuy: sum("monthlyBuy"), monthlyRevenue: sum("monthlyRevenue"), totalBuy: sum("totalBuy"), totalRevenue, totalGp, grossMargin: totalRevenue ? totalGp / totalRevenue : 0, warningCount: rows.filter((row) => row.economics.warning).length };
}

export function buildScenarios(roles: CommercialRole[]) {
  const core = roles.filter((role) => role.layer === "core"); const flex = roles.filter((role) => role.layer === "flex");
  return { lean: core.slice(0, 2), recommended: [...core, ...flex.slice(0, 1)], accelerated: roles };
}
