import { expect, it } from "vitest";
import { buildEconomicsCsv } from "./csv";
import { safeFilename } from "./docx";
import type { CommercialRole } from "@/lib/domain/types";

const role = { id: "r", layer: "core", role: "Data Engineer", seniority: "Senior", capability: "Data", reason: "Reason", owns: "Data", enters: "Phase 1", allocation: 1, durationMonths: 3, engagementType: "contractor", benchmarkRate: 600, buyRate: 600, pricingMode: "target-margin", targetMargin: .4 } as CommercialRole;

it("makes useful client filenames", () => { expect(safeFilename("Acme & Co")).toMatch(/^Elastic Labs – Acme & Co – Outside-In – \d{4}-\d{2}-\d{2}\.docx$/); });
it("keeps economics in the internal CSV", () => { const csv = buildEconomicsCsv([role]); expect(csv).toContain("BUY / day"); expect(csv).toContain("Gross margin"); expect(csv).toContain("Data Engineer"); });
