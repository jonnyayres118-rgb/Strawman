import type { Confidence, EvidenceItem, Opportunity } from "@/lib/domain/types";

export function parseCsv(input: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = "";
  let quoted = false;
  for (let i = 0; i < input.length; i += 1) {
    const char = input[i];
    if (char === '"') {
      if (quoted && input[i + 1] === '"') { field += '"'; i += 1; }
      else quoted = !quoted;
    } else if (char === "," && !quoted) { row.push(field); field = ""; }
    else if ((char === "\n" || char === "\r") && !quoted) {
      if (char === "\r" && input[i + 1] === "\n") i += 1;
      row.push(field); if (row.some((cell) => cell.length)) rows.push(row); row = []; field = "";
    } else field += char;
  }
  if (field.length || row.length) { row.push(field); rows.push(row); }
  return rows;
}

const slug = (value: string) => value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
const optional = (value?: string) => value?.trim() || undefined;

export function mapPipelineRow(headers: string[], row: string[]): Opportunity {
  const cells = Object.fromEntries(headers.map((header, index) => [header, row[index]?.trim() ?? ""]));
  const sourceConfidence = optional(cells["Source / Confidence"]);
  const confidence: Confidence | undefined = /high/i.test(sourceConfidence ?? "") ? "High" : /medium/i.test(sourceConfidence ?? "") ? "Medium" : /low/i.test(sourceConfidence ?? "") ? "Low" : undefined;
  const owner = optional(cells["Owner / Backer"]);
  const contactRaw = optional(cells["LinkedIn / Contact"]);
  const email = contactRaw?.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i)?.[0];
  const linkedin = contactRaw?.match(/(?:https?:\/\/)?(?:www\.)?linkedin\.com\/[^ |]+/i)?.[0];
  const evidence: EvidenceItem[] = [];
  if (cells.Trigger) evidence.push({ id: `${slug(cells.Company)}-trigger`, kind: "fact", summary: cells.Trigger, confidence });
  if (sourceConfidence) evidence.push({ id: `${slug(cells.Company)}-source`, kind: "evidence", summary: cells.Notes || sourceConfidence, sourceTitle: sourceConfidence, confidence });
  if (cells["Why Elastic"]) evidence.push({ id: `${slug(cells.Company)}-inference`, kind: "inference", summary: cells["Why Elastic"], confidence });
  return {
    id: slug(cells.Company || `opportunity-${row[0]}`),
    priority: Number(cells.Priority) || undefined,
    company: cells.Company || "Untitled opportunity",
    score: Math.max(0, Math.min(100, Number(cells.Score) || 0)),
    status: cells.Status || "Researching",
    industry: optional(cells.Wedge), wedge: optional(cells.Wedge), ownership: owner,
    peBacked: !!owner && /pe|capital|partners|alternatives|equity|blixt|apax|bain|goldman/i.test(owner),
    employeeCount: optional(cells.Employees), revenue: optional(cells.Revenue), growth: optional(cells["12m Growth"]),
    technicalBench: optional(cells["Tech / Data Bench"]), complexity: optional(cells.Complexity), trigger: optional(cells.Trigger),
    whyNow: optional(cells.Trigger), whyElastic: optional(cells["Why Elastic"]), hypothesis: optional(cells["Why Elastic"]),
    keyUnknown: optional(cells["Key Unknown"]), discoveryQuestion: optional(cells["Best Discovery Question"]),
    contact: { role: optional(cells["Primary Buyer"]), name: optional(cells["Buyer Name"]), email, linkedin, apollo: contactRaw, relevance: optional(cells["Why Elastic"]) },
    lastTouch: optional(cells["Last Touch"]), nextAction: optional(cells["Next Action"]), nextActionDate: optional(cells["Next Action Date"]),
    outsideInStatus: optional(cells["Outside-In"]), sourceConfidence, notes: optional(cells.Notes), lastResearched: optional(cells["Last Researched"]),
    confidence, active: /^(true|yes|1)$/i.test(cells["Active?"] || "true"), evidence,
  };
}

export function mapPipelineCsv(csv: string): Opportunity[] {
  return mapPipelineValues(parseCsv(csv));
}

export function mapPipelineValues(values: string[][]): Opportunity[] {
  const [headers = [], ...rows] = values;
  return rows.filter((row) => row.some(Boolean)).map((row) => mapPipelineRow(headers, row));
}
