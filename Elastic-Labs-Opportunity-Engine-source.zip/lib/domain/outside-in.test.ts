import { describe, expect, it } from "vitest";
import { buildOutsideIn, duplicateBlock, moveBlock } from "./outside-in";
import type { Opportunity } from "./types";

const base = { id: "lawfront", company: "Lawfront", score: 97, trigger: "Multiple acquisitions and AI rollout", whyElastic: "Integration spikes", keyUnknown: "Bench depth", discoveryQuestion: "Who owns delivery?", industry: "Legal", status: "Research", active: true } as Opportunity;

describe("Outside-In", () => {
  it("creates every mandatory block and hedges inference", () => {
    const result = buildOutsideIn(base);
    expect(result.blocks.map((b) => b.kind)).toEqual(expect.arrayContaining(["cover", "trigger", "exposure", "tension", "capability", "unknown", "question", "core", "flex", "scale", "next"]));
    expect(result.tension).toMatch(/raises a question|If /);
  });

  it("uses stable unique block ids while editing", () => {
    const result = buildOutsideIn(base);
    const copied = duplicateBlock(result.blocks, result.blocks[1].id);
    expect(new Set(copied.map((b) => b.id)).size).toBe(copied.length);
    expect(moveBlock(copied, copied[0].id, 1)[1].id).toBe(copied[0].id);
  });
});
