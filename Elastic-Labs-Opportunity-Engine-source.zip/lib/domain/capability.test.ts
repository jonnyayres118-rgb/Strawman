import { describe, expect, it } from "vitest";
import { buildCapabilityArchitecture } from "./capability";
import type { Opportunity } from "./types";

const make = (company: string, industry: string, trigger: string) => ({ id: company, company, industry, trigger, score: 90, status: "Research", active: true } as Opportunity);

it("keeps Core credible and every role justified", () => {
  const architecture = buildCapabilityArchitecture(make("PIB", "Insurance", "56 acquisitions and platform consolidation"));
  expect(architecture.core.length).toBeGreaterThanOrEqual(2);
  expect(architecture.core.length).toBeLessThanOrEqual(3);
  expect(architecture.core.every((role) => role.reason && role.owns)).toBe(true);
  expect(architecture.flex.every((role) => role.flexTrigger)).toBe(true);
});

it("produces materially different healthcare and acquisition shapes", () => {
  const healthcare = buildCapabilityArchitecture(make("TFP", "Healthcare", "Regulated patient platform growth"));
  const acquisition = buildCapabilityArchitecture(make("PIB", "Insurance", "Multiple acquisitions and integration"));
  expect(healthcare.core.map((r) => r.role)).not.toEqual(acquisition.core.map((r) => r.role));
});
