import { describe, expect, it } from "vitest";
import { calculateRoleEconomics, calculateTeamEconomics } from "./economics";
import type { CommercialRole } from "./types";

const role = { id: "1", layer: "core", role: "AI Product Lead", seniority: "Principal", capability: "AI product delivery", reason: "Owns proof", owns: "Outcome", enters: "Phase 1", allocation: 1, durationMonths: 6, engagementType: "contractor", benchmarkRate: 700, buyRate: 700, pricingMode: "target-margin", targetMargin: 0.4 } as CommercialRole;

it("distinguishes gross margin from markup", () => {
  const result = calculateRoleEconomics(role);
  expect(result.sellRate).toBeCloseTo(1166.67, 1);
  expect(result.grossMargin).toBeCloseTo(0.4, 3);
  expect(result.markup).toBeCloseTo(0.6667, 3);
});

it("respects allocation and duration in totals", () => {
  const result = calculateTeamEconomics([{ ...role, allocation: 0.5, durationMonths: 3 }]);
  expect(result.headcount).toBe(1);
  expect(result.totalRevenue).toBeGreaterThan(result.totalBuy);
  expect(result.grossMargin).toBeCloseTo(0.4, 2);
});
