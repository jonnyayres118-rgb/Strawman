# Elastic Labs Opportunity Engine Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Ship a Vercel-hosted V1 that moves a live Sheet-backed opportunity through evidence-led Outside-In creation, Core / Flex / Scale architecture, commercial modelling, and safe client exports.

**Architecture:** Next.js App Router with pure TypeScript domain modules, server adapters for Google Sheets and Google Drive, and local-storage authored state. Client-facing serializers are allow-list transformations shared by PDF, DOCX, and Google Docs publishers.

**Tech Stack:** Next.js 15, React 19, TypeScript, Vitest, Testing Library, docx, jsPDF, Papa Parse, Lucide React, Vercel.

**Spec:** `docs/superpowers/specs/2026-08-25-elastic-opportunity-engine-design.md`

## Global Constraints

- Opportunity, not contact, is the central object.
- Outside-Ins are generated only after a human clicks Build Outside-In.
- Missing Sheet fields remain optional and must not be fabricated.
- Fact, evidence, inference, and hypothesis are visibly distinct.
- Core / Flex / Scale roles require an explicit reason for inclusion.
- Client outputs never include BUY, GP, GM, markup, bench, utilisation, compensation, or internal assumptions.
- Open in Google Docs must target the exact created document and must never open `docs.new`.
- Text inputs autosize and retain focus while typing.
- No report is sent automatically.

---

### Task 1: Project foundation and domain contracts

**Files:**
- Create: `package.json`, `tsconfig.json`, `next.config.ts`, `vitest.config.ts`, `app/layout.tsx`, `app/globals.css`
- Create: `lib/domain/types.ts`, `lib/domain/constants.ts`
- Test: `lib/domain/types.test.ts`

**Interfaces:**
- Produces: `Opportunity`, `EvidenceItem`, `OutsideIn`, `CapabilityRole`, `CommercialRole`, `ClientDocument` and workflow enums.

- [ ] Write a compile-time and runtime fixture test that exercises an opportunity with missing optional Sheet fields.
- [ ] Run `npm test -- lib/domain/types.test.ts` and verify it fails because the contracts do not exist.
- [ ] Add the minimal project and domain files.
- [ ] Re-run the focused test and verify it passes.
- [ ] Commit the foundation.

### Task 2: Sheet adapter and resilient opportunity source

**Files:**
- Create: `lib/integrations/sheets.ts`, `lib/data/seed-opportunities.ts`, `app/api/opportunities/route.ts`
- Test: `lib/integrations/sheets.test.ts`

**Interfaces:**
- Consumes: `Opportunity`.
- Produces: `mapPipelineRow(headers: string[], row: string[]): Opportunity` and `GET /api/opportunities` returning `{ opportunities, source, warning? }`.

- [ ] Write failing tests for exact current headers, blank values, confidence parsing, source preservation, and descending score order.
- [ ] Run the focused test and verify expected missing-module failures.
- [ ] Implement header-index mapping and the public Google Sheets CSV adapter with a seeded fallback.
- [ ] Re-run the focused test and verify it passes.
- [ ] Commit the adapter.

### Task 3: Opportunity ranking, filtering, and workspace

**Files:**
- Create: `lib/domain/opportunities.ts`, `components/app-shell.tsx`, `components/opportunities/opportunity-list.tsx`, `components/opportunities/opportunity-workspace.tsx`, `app/page.tsx`
- Test: `lib/domain/opportunities.test.ts`, `components/opportunities/opportunity-list.test.tsx`

**Interfaces:**
- Consumes: `Opportunity[]` from `/api/opportunities`.
- Produces: `rankOpportunities`, `filterOpportunities`, selection state, and the four-question workspace.

- [ ] Write failing tests for score ordering, 80+ priority, combined filters, and workspace claim labels.
- [ ] Verify the tests fail for missing behaviour.
- [ ] Implement the dashboard, top-three daily view, filter bar, and workspace.
- [ ] Re-run the tests and verify they pass.
- [ ] Commit the opportunity experience.

### Task 4: Outside-In generation and editor

**Files:**
- Create: `lib/domain/outside-in.ts`, `components/outside-in/outside-in-editor.tsx`, `components/ui/autosize-textarea.tsx`, `lib/storage.ts`
- Test: `lib/domain/outside-in.test.ts`, `components/ui/autosize-textarea.test.tsx`

**Interfaces:**
- Consumes: `Opportunity`.
- Produces: `buildOutsideIn(opportunity): OutsideIn`, stable block CRUD/reorder functions, and autosizing controlled inputs.

- [ ] Write failing tests for all mandatory sections, hedged inference language, different trigger templates, stable block IDs, and focus retention.
- [ ] Verify each test fails for the missing feature.
- [ ] Implement deliberate generation, persistent authored state, and editable ordered blocks.
- [ ] Re-run the focused tests and verify they pass.
- [ ] Commit the Outside-In editor.

### Task 5: Core / Flex / Scale architecture and strawman conversion

**Files:**
- Create: `lib/domain/capability.ts`, `components/capability/capability-architecture.tsx`, `components/strawman/team-builder.tsx`
- Test: `lib/domain/capability.test.ts`

**Interfaces:**
- Consumes: `Opportunity` and `OutsideIn`.
- Produces: `buildCapabilityArchitecture` and `toCommercialRoles`.

- [ ] Write failing tests for acquisition, professional services, AI transformation, healthcare, and operational technology shapes.
- [ ] Verify the tests fail because the generator is absent.
- [ ] Implement trigger/wedge-aware architectures with 2–3 Core roles and justified Flex/Scale roles.
- [ ] Implement role add, edit, duplicate, remove, reorder, and layer movement.
- [ ] Re-run tests and verify they pass.
- [ ] Commit capability and strawman conversion.

### Task 6: True-buy economics, pricing, scenarios, and deployment

**Files:**
- Create: `lib/domain/economics.ts`, `lib/data/benchmarks.ts`, `components/strawman/economics-panel.tsx`, `components/strawman/deployment-timeline.tsx`
- Test: `lib/domain/economics.test.ts`

**Interfaces:**
- Consumes: `CommercialRole[]` and `CommercialAssumptions`.
- Produces: `calculateRoleEconomics`, `calculateTeamEconomics`, `buildScenarios`, and phased totals.

- [ ] Write failing tests for engagement-specific true buy, target-margin, markup, manual sell, GM/markup distinction, low-margin warnings, allocation, and duration.
- [ ] Verify the calculation tests fail for the intended missing functions.
- [ ] Implement benchmarks, assumptions, pure calculators, scenarios, and phase summaries.
- [ ] Re-run tests and verify exact numeric expectations pass.
- [ ] Commit commercial modelling.

### Task 7: Client-safety boundary and exports

**Files:**
- Create: `lib/domain/client-document.ts`, `lib/exports/docx.ts`, `lib/exports/pdf.ts`, `lib/exports/csv.ts`, `components/export/export-centre.tsx`
- Test: `lib/domain/client-document.test.ts`, `lib/exports/exports.test.ts`

**Interfaces:**
- Consumes: complete internal opportunity state.
- Produces: `toClientDocument`, `buildDocx`, `buildPdf`, and `buildEconomicsCsv`.

- [ ] Write failing allow-list and forbidden-term/value leakage tests.
- [ ] Verify tests fail because the serializers are missing.
- [ ] Implement client serializer first, then make PDF and DOCX consume only `ClientDocument`.
- [ ] Implement internal CSV from economics rows.
- [ ] Re-run leakage and export tests and verify they pass.
- [ ] Commit safe exports.

### Task 8: Exact Google Docs publishing

**Files:**
- Create: `lib/integrations/google-drive.ts`, `app/api/google-docs/route.ts`
- Modify: `components/export/export-centre.tsx`
- Test: `lib/integrations/google-drive.test.ts`, `app/api/google-docs/route.test.ts`

**Interfaces:**
- Consumes: validated `ClientDocument` and optional `fileId`.
- Produces: `{ fileId: string; url: string; updated: boolean }`.

- [ ] Write failing tests proving only client-safe payloads are accepted and the returned URL targets the returned file ID.
- [ ] Verify the tests fail for the absent route.
- [ ] Implement refresh-token exchange, DOCX upload/conversion, update confirmation, linked-document storage, and actionable missing-config response.
- [ ] Verify opening an existing link does not publish or overwrite.
- [ ] Re-run focused tests and verify they pass.
- [ ] Commit Google Docs publishing.

### Task 9: Integrated navigation, polish, and responsive behaviour

**Files:**
- Modify: `app/page.tsx`, `app/globals.css`, all feature components
- Create: `components/ui/icons.tsx`, `public/elastic-mark.svg`
- Test: `components/app-shell.test.tsx`

**Interfaces:**
- Consumes all completed feature modules.
- Produces the daily end-to-end application flow.

- [ ] Write failing navigation tests for Opportunities → Outside-In → Strawman → Export.
- [ ] Verify the tests fail before integration.
- [ ] Implement the warm editorial visual system, responsive navigation, empty/loading/error states, and persistent progress.
- [ ] Re-run component and unit tests.
- [ ] Commit integrated UI polish.

### Task 10: Full verification, GitHub commit, and Vercel deployment

**Files:**
- Modify: `README.md`, `.env.example`
- Create: `e2e/opportunity-flow.spec.ts` if Playwright is available.

**Interfaces:**
- Produces a verified production deployment linked to `jonnyayres118-rgb/Strawman`.

- [ ] Run `npm test` and confirm zero failures.
- [ ] Run `npm run lint` and confirm zero errors.
- [ ] Run `npm run build` and confirm exit code 0.
- [ ] Start the production server and browser-test ranking, deliberate Outside-In generation, editing/focus retention, strawman conversion, calculations, client/internal separation, and export actions.
- [ ] Scan the requirements in the design spec and record any disclosed environment-only limitation.
- [ ] Commit and push the verified tree to `main` in `jonnyayres118-rgb/Strawman`.
- [ ] Confirm the connected Vercel deployment is READY, open the production URL, and check runtime errors.
