# Elastic Labs Opportunity Engine

An evidence-led opportunity-to-capability platform for Elastic Labs.

## What V1 does

- Ingests and ranks the existing Elastic Labs Pipeline Google Sheet, with a resilient realistic fallback.
- Keeps facts, evidence, inferences and hypotheses visibly distinct.
- Generates an Outside-In only when a user deliberately selects **Build Outside-In**.
- Creates trigger-specific Core / Flex / Scale capability architectures.
- Converts the architecture into an editable team and commercial model.
- Calculates true BUY, SELL, gross profit, gross margin and markup without confusing margin and markup.
- Keeps internal economics out of every client serializer.
- Downloads client-safe PDF and genuine editable DOCX files, plus an internal economics CSV.
- Creates and opens the exact native Google Doc when Google Drive credentials are configured.

## Local setup

```bash
npm install
npm run dev
```

Copy `.env.example` to `.env.local` for integration values. The opportunity route uses `GOOGLE_SHEET_ID`. Native Google Docs publishing uses server-only `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, and `GOOGLE_REFRESH_TOKEN` with a refresh token that has Google Drive file creation permission.

## Verification

```bash
npm test
npm run lint
npm run build
```

Google Docs publishing never falls back to `docs.new`. If credentials are missing, the app explains the configuration gap and keeps the editable DOCX fallback available.
