export const BENCHMARKS: Record<string, Record<string, number>> = {
  "AI Product Lead": { Principal: 750, Senior: 650 },
  "AI Engineer": { Principal: 800, Senior: 650, Mid: 525 },
  "Data Engineer": { Principal: 750, Senior: 625, Mid: 500 },
  "Platform Integration Lead": { Principal: 775, Senior: 650 },
  "Product Manager": { Principal: 700, Senior: 575 },
  "Cloud / DevOps Engineer": { Principal: 750, Senior: 625 },
  "MLOps Engineer": { Principal: 800, Senior: 675 },
  "Product Designer": { Principal: 650, Senior: 525 },
  "Security Architect": { Principal: 850, Senior: 725 },
  "Change & Adoption Lead": { Principal: 675, Senior: 550 },
  "Clinical Data Engineer": { Principal: 800, Senior: 675 },
};

export function benchmarkFor(role: string, seniority: string): number { return BENCHMARKS[role]?.[seniority] ?? (seniority === "Principal" ? 750 : seniority === "Senior" ? 625 : 500); }
