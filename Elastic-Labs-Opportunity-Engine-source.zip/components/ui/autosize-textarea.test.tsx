import { fireEvent, render, screen } from "@testing-library/react";
import { expect, it, vi } from "vitest";
import { AutosizeTextarea } from "./autosize-textarea";

it("keeps focus while a controlled value changes", () => {
  const onChange = vi.fn();
  const { rerender } = render(<AutosizeTextarea aria-label="Copy" value="A" onChange={onChange} />);
  const input = screen.getByLabelText("Copy");
  input.focus();
  fireEvent.change(input, { target: { value: "AB" } });
  rerender(<AutosizeTextarea aria-label="Copy" value="AB" onChange={onChange} />);
  expect(document.activeElement).toBe(input);
});
