import { calculateRoleEconomics } from "@/lib/domain/economics";
import type { CommercialAssumptions, CommercialRole } from "@/lib/domain/types";

const cell = (value: string | number) => `"${String(value).replace(/"/g, '""')}"`;
export function buildEconomicsCsv(roles: CommercialRole[], assumptions?: CommercialAssumptions): string {
  const headers = ["Layer", "Role", "Seniority", "Allocation", "Duration months", "Engagement", "Benchmark", "BUY / day", "SELL / day", "GP / day", "Gross margin", "Markup", "Total revenue", "Total GP"];
  const rows = roles.map((role) => { const e = calculateRoleEconomics(role, assumptions); return [role.layer, role.role, role.seniority, role.allocation, role.durationMonths, role.engagementType, role.benchmarkRate, e.trueBuyRate.toFixed(2), e.sellRate.toFixed(2), e.gpPerDay.toFixed(2), `${(e.grossMargin * 100).toFixed(1)}%`, `${(e.markup * 100).toFixed(1)}%`, e.totalRevenue.toFixed(2), e.totalGp.toFixed(2)]; });
  return [headers, ...rows].map((row) => row.map(cell).join(",")).join("\n");
}
