export type Confidence = "High" | "Medium" | "Low";
export type ClaimKind = "fact" | "evidence" | "inference" | "hypothesis";
export type CapabilityLayer = "core" | "flex" | "scale";
export type WorkflowStatus = "Researching" | "Qualified" | "Outside-In Draft" | "Ready for Review" | "Approved" | "Sent" | "Conversation" | "Opportunity" | "Won" | "Lost" | string;
export type BlockKind = "cover" | "intro" | "trigger" | "exposure" | "tension" | "capability" | "unknown" | "question" | "core" | "flex" | "scale" | "help" | "next" | "text" | "image";
export type EngagementType = "employee" | "contractor" | "freelancer";
export type PricingMode = "target-margin" | "markup" | "manual";

export interface EvidenceItem {
  id: string;
  kind: ClaimKind;
  summary: string;
  sourceUrl?: string;
  sourceTitle?: string;
  publicationDate?: string;
  excerpt?: string;
  confidence?: Confidence;
}

export interface Contact {
  name?: string;
  role?: string;
  email?: string;
  linkedin?: string;
  apollo?: string;
  relevance?: string;
}

export interface ReportBlock {
  id: string;
  kind: BlockKind;
  title: string;
  content: string;
  hidden?: boolean;
  imageUrl?: string;
}

export interface OutsideIn {
  trigger: string;
  exposure: string;
  tension: string;
  capabilityHypothesis: string;
  criticalUnknown: string;
  discoveryQuestion: string;
  blocks: ReportBlock[];
  updatedAt: string;
}

export interface CapabilityRole {
  id: string;
  layer: CapabilityLayer;
  role: string;
  seniority: string;
  capability: string;
  reason: string;
  owns: string;
  enters: string;
  allocation: number;
  durationMonths: number;
  engagementType: EngagementType;
  flexTrigger?: string;
}

export interface CapabilityArchitecture {
  framing: string;
  core: CapabilityRole[];
  flex: CapabilityRole[];
  scale: CapabilityRole[];
}

export interface CommercialRole extends CapabilityRole {
  benchmarkRate: number;
  buyRate: number;
  pricingMode: PricingMode;
  targetMargin?: number;
  targetMarkup?: number;
  sellRate?: number;
  salaryBenchmark?: number;
  employerOnCostsPct?: number;
  deliveryOverheadPerDay?: number;
  gp?: number;
  grossMargin?: number;
  markup?: number;
}

export interface CommercialAssumptions {
  billableDaysPerMonth: number;
  targetMargin: number;
  employerOnCostsPct: number;
  employeeWorkingDays: number;
  equipmentAnnual: number;
  softwareMonthly: number;
  recruitmentPct: number;
  managementPct: number;
  benchPct: number;
  eorMonthly: number;
}

export interface Strawman {
  roles: CommercialRole[];
  assumptions?: CommercialAssumptions;
}

export interface Opportunity {
  id: string;
  priority?: number;
  company: string;
  website?: string;
  score: number;
  confidence?: Confidence;
  status: WorkflowStatus;
  industry?: string;
  wedge?: string;
  ownership?: string;
  peBacked?: boolean;
  employeeCount?: string;
  revenue?: string;
  growth?: string;
  technicalBench?: string;
  complexity?: string;
  trigger?: string;
  triggerDate?: string;
  whyNow?: string;
  whyElastic?: string;
  hypothesis?: string;
  keyUnknown?: string;
  discoveryQuestion?: string;
  contact?: Contact;
  outreachStatus?: string;
  lastTouch?: string;
  nextAction?: string;
  nextActionDate?: string;
  outsideInStatus?: string;
  sourceConfidence?: string;
  notes?: string;
  lastResearched?: string;
  active: boolean;
  evidence?: EvidenceItem[];
  outsideIn?: OutsideIn;
  architecture?: CapabilityArchitecture;
  strawman?: Strawman;
  googleDoc?: { fileId: string; url: string; lastSyncedAt: string };
}

export interface OpportunityFilters {
  minScore?: number;
  industry?: string;
  trigger?: string;
  peBacked?: "all" | "yes" | "no";
  revenue?: string;
  employees?: string;
  confidence?: string;
  status?: string;
  search?: string;
}

export interface ClientRole {
  layer: CapabilityLayer;
  role: string;
  seniority: string;
  capability: string;
  reason: string;
  owns: string;
  enters: string;
  allocation: number;
  durationMonths: number;
}

export interface ClientDocument {
  title: string;
  company: string;
  date: string;
  status: string;
  sections: Array<{ id: string; kind: BlockKind; title: string; content: string; imageUrl?: string }>;
  roles: ClientRole[];
  investment?: { monthly: number; total: number; durationMonths: number; currency: "GBP" };
}
