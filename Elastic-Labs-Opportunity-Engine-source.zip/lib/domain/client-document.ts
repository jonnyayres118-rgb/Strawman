import { calculateTeamEconomics } from "./economics";
import type { ClientDocument, Opportunity } from "./types";

export function toClientDocument(opportunity: Opportunity): ClientDocument {
  const roles = opportunity.strawman?.roles ?? [];
  const clientRoles = roles.map(({ layer, role, seniority, capability, reason, owns, enters, allocation, durationMonths }) => ({ layer, role, seniority, capability, reason, owns, enters, allocation, durationMonths }));
  const economics = roles.length ? calculateTeamEconomics(roles, opportunity.strawman?.assumptions) : undefined;
  const maxDuration = roles.reduce((max, role) => Math.max(max, role.durationMonths), 0);
  return {
    title: `Elastic Labs – ${opportunity.company} – Outside-In`, company: opportunity.company,
    date: new Intl.DateTimeFormat("en-GB", { day: "numeric", month: "long", year: "numeric", timeZone: "Europe/London" }).format(new Date()),
    status: opportunity.status,
    sections: (opportunity.outsideIn?.blocks ?? []).filter((item) => !item.hidden).map(({ id, kind, title, content, imageUrl }) => ({ id, kind, title, content, imageUrl })),
    roles: clientRoles,
    investment: economics ? { monthly: Math.round(economics.monthlyRevenue), total: Math.round(economics.totalRevenue), durationMonths: maxDuration, currency: "GBP" } : undefined,
  };
}
