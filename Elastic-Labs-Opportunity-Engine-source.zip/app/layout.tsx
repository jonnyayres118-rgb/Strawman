import type { Metadata } from "next";
import "./globals.css";
import "./uploads.css";

export const metadata: Metadata = {
  title: "Elastic Labs Opportunity Engine",
  description: "Evidence-led opportunity intelligence, capability architecture and commercial modelling for Elastic Labs.",
  robots: { index: false, follow: false },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
