import type { Opportunity, OpportunityFilters } from "./types";

export function rankOpportunities(records: Opportunity[]): Opportunity[] {
  return [...records].filter((item) => item.active).sort((a, b) => b.score - a.score || a.company.localeCompare(b.company));
}

export function filterOpportunities(records: Opportunity[], filters: OpportunityFilters): Opportunity[] {
  const text = filters.search?.trim().toLowerCase();
  return rankOpportunities(records).filter((item) => {
    if (filters.minScore && item.score < filters.minScore) return false;
    if (filters.industry && filters.industry !== "all" && item.industry !== filters.industry) return false;
    if (filters.confidence && filters.confidence !== "all" && item.confidence !== filters.confidence) return false;
    if (filters.status && filters.status !== "all" && item.status !== filters.status) return false;
    if (filters.peBacked === "yes" && !item.peBacked) return false;
    if (filters.peBacked === "no" && item.peBacked) return false;
    if (filters.trigger && !item.trigger?.toLowerCase().includes(filters.trigger.toLowerCase())) return false;
    if (filters.revenue && !item.revenue?.toLowerCase().includes(filters.revenue.toLowerCase())) return false;
    if (filters.employees && !item.employeeCount?.toLowerCase().includes(filters.employees.toLowerCase())) return false;
    if (text) {
      const haystack = [item.company, item.industry, item.trigger, item.whyElastic, item.ownership, item.contact?.name].filter(Boolean).join(" ").toLowerCase();
      if (!haystack.includes(text)) return false;
    }
    return true;
  });
}
