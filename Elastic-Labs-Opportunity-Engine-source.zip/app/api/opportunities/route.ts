import { NextResponse } from "next/server";
import { seedOpportunities } from "@/lib/data/seed-opportunities";
import { rankOpportunities } from "@/lib/domain/opportunities";
import { mapPipelineCsv, mapPipelineValues } from "@/lib/integrations/sheets";
import { getGoogleAccessToken } from "@/lib/integrations/google-drive";

const SHEET_ID = process.env.GOOGLE_SHEET_ID || "1y61_TDijUNEFAXZX2hkM_jq28fmuk2yMWhWoy3psi3w";

export async function GET() {
  const issues: string[] = [];
  if (process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET && process.env.GOOGLE_REFRESH_TOKEN) {
    try {
      const token = await getGoogleAccessToken(process.env, fetch);
      const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${SHEET_ID}/values/${encodeURIComponent("Pipeline!A:Z")}`, { headers: { Authorization: `Bearer ${token}` }, next: { revalidate: 300 } });
      if (!response.ok) throw new Error(`Authenticated Sheet returned ${response.status}`);
      const body = await response.json() as { values?: string[][] }; const mapped = mapPipelineValues(body.values || []);
      if (!mapped.length) throw new Error("Authenticated Sheet returned no opportunities");
      return NextResponse.json({ opportunities: rankOpportunities(mapped), source: "Google Sheet" });
    } catch (error) { issues.push(error instanceof Error ? error.message : "Authenticated Sheet unavailable"); }
  }
  try {
    const url = `https://docs.google.com/spreadsheets/d/${SHEET_ID}/gviz/tq?tqx=out:csv&sheet=Pipeline`;
    const response = await fetch(url, { next: { revalidate: 300 } });
    if (!response.ok) throw new Error(`Sheet returned ${response.status}`);
    const mapped = mapPipelineCsv(await response.text());
    if (!mapped.length) throw new Error("Sheet returned no opportunities");
    return NextResponse.json({ opportunities: rankOpportunities(mapped), source: "Google Sheet" });
  } catch (error) {
    issues.push(error instanceof Error ? error.message : "Sheet unavailable");
    return NextResponse.json({ opportunities: rankOpportunities(seedOpportunities), source: "Seed data", warning: issues.join("; ") });
  }
}
