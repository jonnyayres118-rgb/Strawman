import { NextRequest, NextResponse } from "next/server";
import { createGoogleDoc, validateClientPayload } from "@/lib/integrations/google-drive";

export const runtime = "nodejs";
export async function POST(request: NextRequest) {
  try { const body = await request.json(); validateClientPayload(body.document); const result = await createGoogleDoc(body.document); return NextResponse.json(result); }
  catch (error) { const message = error instanceof Error ? error.message : "Unable to create Google Doc"; const missing = message === "GOOGLE_NOT_CONFIGURED"; return NextResponse.json({ error: missing ? "Google Docs publishing is not configured on this deployment. Add the Google OAuth credentials in Vercel; editable DOCX remains available." : message, code: missing ? "GOOGLE_NOT_CONFIGURED" : "GOOGLE_DOCS_ERROR" }, { status: missing ? 503 : 400 }); }
}
