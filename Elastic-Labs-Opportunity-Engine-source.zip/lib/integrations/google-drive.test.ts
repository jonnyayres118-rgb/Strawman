import { expect, it } from "vitest";
import { googleDocEditUrl, validateClientPayload } from "./google-drive";

it("opens the exact returned native Google Doc", () => { expect(googleDocEditUrl("abc123")).toBe("https://docs.google.com/document/d/abc123/edit"); });
it("rejects payloads carrying internal economics keys", () => { expect(() => validateClientPayload({ title: "x", company: "x", buyRate: 700 })).toThrow(/client-safe/i); });
