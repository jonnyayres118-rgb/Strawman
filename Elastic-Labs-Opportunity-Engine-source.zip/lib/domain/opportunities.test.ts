import { describe, expect, it } from "vitest";
import { filterOpportunities, rankOpportunities } from "./opportunities";
import type { Opportunity } from "./types";

const records = [
  { id: "b", company: "B", score: 82, confidence: "Medium", industry: "Healthcare", peBacked: false, status: "Research", active: true },
  { id: "a", company: "A", score: 94, confidence: "High", industry: "Insurance", peBacked: true, status: "Qualified", active: true },
] as Opportunity[];

it("ranks active opportunities by score", () => {
  expect(rankOpportunities(records).map((r) => r.company)).toEqual(["A", "B"]);
});

it("combines score, industry, and PE filters", () => {
  expect(filterOpportunities(records, { minScore: 90, industry: "Insurance", peBacked: "yes" })).toHaveLength(1);
});
