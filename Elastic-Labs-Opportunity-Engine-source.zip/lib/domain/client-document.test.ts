import { expect, it } from "vitest";
import { toClientDocument } from "./client-document";
import type { Opportunity } from "./types";

it("allow-lists client content and excludes internal economics", () => {
  const source = { id: "x", company: "Client", score: 90, status: "Approved", active: true, trigger: "Acquisition", whyElastic: "Integration", outsideIn: { blocks: [{ id: "img", kind: "image", title: "Methodology", content: "Reusable methodology slide", imageUrl: "data:image/png;base64,AAAA" }] }, strawman: { roles: [{ id: "r", role: "Data Engineer", seniority: "Senior", capability: "Data integration", layer: "core", reason: "Builds pipelines", owns: "Data", enters: "Phase 1", allocation: 1, durationMonths: 6, engagementType: "contractor", benchmarkRate: 700, buyRate: 700, sellRate: 1200, gp: 500, grossMargin: 0.416, markup: 0.714 }] } } as unknown as Opportunity;
  const client = toClientDocument(source);
  const serialised = JSON.stringify(client).toLowerCase();
  for (const forbidden of ["buyrate", "grossmargin", "markup", "bench", "utilisation", "compensation", '"gp"']) expect(serialised).not.toContain(forbidden);
  expect(client.company).toBe("Client");
  expect(client.sections[0].imageUrl).toBe("data:image/png;base64,AAAA");
});
