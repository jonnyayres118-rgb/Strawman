import { describe, expect, it } from "vitest";
import { mapPipelineRow, mapPipelineValues, parseCsv } from "./sheets";

const headers = ["Priority", "Company", "Score", "Status", "Wedge", "Owner / Backer", "Employees", "Revenue", "12m Growth", "Tech / Data Bench", "Complexity", "Trigger", "Why Elastic", "Key Unknown", "Best Discovery Question", "Primary Buyer", "Buyer Name", "LinkedIn / Contact", "Last Touch", "Next Action", "Next Action Date", "Outside-In", "Source / Confidence", "Notes", "Last Researched", "Active?"];

describe("Sheet mapping", () => {
  it("maps present values and leaves missing values undefined", () => {
    const row = ["1", "Lawfront", "97", "Research", "Legal", "Blixt", "", "£130m+", "", "", "7 firms", "Refinancing + AI rollout", "Integration spikes", "Bench depth", "Who owns delivery?", "CIO", "Tony McKenna", "", "", "Build Outside-In", "", "Build", "High — public sources", "Notes", "2026-08-25", "TRUE"];
    const result = mapPipelineRow(headers, row);
    expect(result.company).toBe("Lawfront");
    expect(result.score).toBe(97);
    expect(result.employeeCount).toBeUndefined();
    expect(result.confidence).toBe("High");
    expect(result.active).toBe(true);
  });

  it("parses quoted commas and escaped quotes", () => {
    expect(parseCsv('Company,Notes\n"A, Ltd","Said ""hello"""')).toEqual([
      ["Company", "Notes"],
      ["A, Ltd", 'Said "hello"'],
    ]);
  });

  it("maps authenticated Google Sheets values", () => {
    expect(mapPipelineValues([headers, ["1", "Lawfront", "97", "Research"]])[0].company).toBe("Lawfront");
  });
});
