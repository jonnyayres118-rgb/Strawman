import type { Opportunity, OutsideIn, ReportBlock } from "./types";

let sequence = 0;
const id = (kind: string) => `${kind}-${Date.now().toString(36)}-${(sequence += 1).toString(36)}`;
const block = (kind: ReportBlock["kind"], title: string, content: string): ReportBlock => ({ id: id(kind), kind, title, content });

export function buildOutsideIn(opportunity: Opportunity): OutsideIn {
  const trigger = opportunity.trigger || "A material change appears to be underway.";
  const exposure = opportunity.industry?.toLowerCase().includes("health")
    ? "From the outside, this could affect regulated data flows, patient experience, platform reliability and the pace at which digital change can be deployed safely."
    : /acquisition|merger|consolidat|integration/i.test(trigger)
      ? "From the outside, repeated change could affect systems integration, data consistency, operational workflows and the ability to standardise platforms without slowing the business."
      : "From the outside, this could affect product delivery, data foundations, automation and the specialist capability available to turn the programme into working operations.";
  const tension = `From the outside, this raises a question: if ${trigger.toLowerCase()} is creating several competing delivery priorities, can the permanent team absorb every specialist workstream without either slowing the programme or adding capability that is only needed temporarily?`;
  const capabilityHypothesis = opportunity.whyElastic || (/ai/i.test(trigger) ? "AI product delivery, data engineering and the infrastructure required to move from experiments into production." : "Product leadership, data engineering and platform integration capability assembled around the highest-value workstream.");
  const criticalUnknown = opportunity.keyUnknown || "We cannot know from the outside how much specialist delivery capacity already sits inside the team or with incumbent partners.";
  const discoveryQuestion = opportunity.discoveryQuestion || "When delivery requires specialist technology, data or AI capability today, who actually picks it up?";
  const framing = "If the hypothesis is directionally correct, an illustrative capability model could look like this.";
  const blocks = [
    block("cover", `${opportunity.company}: an Outside-In`, "A perspective on the change we can see, what it might mean, and the capability that could sit around it."),
    block("intro", "Why we're reaching out", `We have been looking at ${opportunity.company} because the visible change appears commercially consequential. This is an Outside-In hypothesis, not a claim that discovery has already happened.`),
    block("trigger", "Trigger", trigger), block("exposure", "Exposure", exposure), block("tension", "Tension", tension),
    block("capability", "Capability hypothesis", capabilityHypothesis), block("unknown", "Critical unknown", criticalUnknown), block("question", "Discovery question", discoveryQuestion),
    block("core", "Core: prove the hypothesis", framing), block("flex", "Flex: add specialist capability", "Specialist capability enters only when evidence or delivery conditions demand it."),
    block("scale", "Scale: industrialise what works", "Additional capacity is introduced only after value is proven."), block("help", "How Elastic Labs could help", "Elastic Labs assembles and manages embedded capability around the work without forcing a large permanent team before the value is known."),
    block("next", "Next step", "Use one focused conversation to validate or invalidate the critical unknown, then decide whether a small proof team is warranted."),
  ];
  return { trigger, exposure, tension, capabilityHypothesis, criticalUnknown, discoveryQuestion, blocks, updatedAt: new Date().toISOString() };
}

export function duplicateBlock(blocks: ReportBlock[], blockId: string): ReportBlock[] {
  const index = blocks.findIndex((item) => item.id === blockId); if (index < 0) return blocks;
  const copy = { ...blocks[index], id: id(blocks[index].kind), title: `${blocks[index].title} copy` };
  return [...blocks.slice(0, index + 1), copy, ...blocks.slice(index + 1)];
}

export function moveBlock(blocks: ReportBlock[], blockId: string, delta: number): ReportBlock[] {
  const index = blocks.findIndex((item) => item.id === blockId); const target = Math.max(0, Math.min(blocks.length - 1, index + delta));
  if (index < 0 || index === target) return blocks; const next = [...blocks]; const [item] = next.splice(index, 1); next.splice(target, 0, item); return next;
}
