import type { CommercialAssumptions } from "./types";

export const DEFAULT_ASSUMPTIONS: CommercialAssumptions = {
  billableDaysPerMonth: 18,
  targetMargin: 0.4,
  employerOnCostsPct: 0.386,
  employeeWorkingDays: 167,
  equipmentAnnual: 1800,
  softwareMonthly: 180,
  recruitmentPct: 0.08,
  managementPct: 0.06,
  benchPct: 0.08,
  eorMonthly: 450,
};

export const WORKFLOW_STATES = ["Researching", "Qualified", "Outside-In Draft", "Ready for Review", "Approved", "Sent", "Conversation", "Opportunity", "Won", "Lost"];
export const MARGIN_WARNING_THRESHOLD = 0.35;
