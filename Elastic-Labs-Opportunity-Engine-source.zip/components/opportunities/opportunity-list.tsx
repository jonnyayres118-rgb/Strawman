"use client";
import { ArrowUpRight, Building2, Filter, Search, Sparkles } from "lucide-react";
import type { Opportunity, OpportunityFilters } from "@/lib/domain/types";
import { filterOpportunities } from "@/lib/domain/opportunities";

export function OpportunityList({ opportunities, filters, onFilters, onSelect, onBuild, source, warning }: { opportunities: Opportunity[]; filters: OpportunityFilters; onFilters: (next: OpportunityFilters) => void; onSelect: (id: string) => void; onBuild: (id: string) => void; source: string; warning?: string }) {
  const visible = filterOpportunities(opportunities, filters); const today = visible.slice(0, 3);
  const industries = Array.from(new Set(opportunities.map((item) => item.industry).filter(Boolean) as string[]));
  const statuses = Array.from(new Set(opportunities.map((item) => item.status).filter(Boolean)));
  return <div className="page-stack">
    <section className="page-intro"><div><span className="eyebrow">Daily commercial intelligence</span><h1>Opportunities</h1><p>Who appears to need Elastic Labs right now, and why?</p></div><div className="source-pill"><span className={`status-dot ${warning ? "warn-dot" : ""}`} />{source}{warning ? " · fallback active" : " · live"}</div></section>
    <section><div className="section-heading"><div><span className="section-number">01</span><h2>Today&apos;s opportunities</h2></div><p>The three companies worth your attention first.</p></div>
      <div className="today-grid">{today.map((item, index) => <article className="today-card" key={item.id}>
        <div className="today-top"><span className="rank">0{index + 1}</span><span className={`score ${item.score >= 90 ? "hot" : ""}`}>{item.score}<small>/100</small></span></div>
        <button className="company-link" onClick={() => onSelect(item.id)}>{item.company}<ArrowUpRight size={18}/></button>
        <div className="meta-line"><span>{item.industry || "Unclassified"}</span><span>{item.ownership || "Ownership unknown"}</span></div>
        <div className="signal"><span>Trigger</span><p>{item.trigger || "Research signal awaiting detail."}</p></div>
        <div className="signal muted-signal"><span>Hypothesis</span><p>{item.whyElastic || "Capability hypothesis awaiting research."}</p></div>
        <div className="card-actions"><button className="btn secondary" onClick={() => onSelect(item.id)}>View research</button><button className="btn primary" onClick={() => onBuild(item.id)}><Sparkles size={15}/>Build Outside-In</button></div>
      </article>)}</div>
    </section>
    <section className="all-opportunities"><div className="section-heading"><div><span className="section-number">02</span><h2>Ranked pipeline</h2></div><p>{visible.length} active opportunities</p></div>
      <div className="filter-bar"><label className="search-field"><Search size={16}/><input aria-label="Search opportunities" placeholder="Search company, trigger or buyer" value={filters.search || ""} onChange={(e) => onFilters({ ...filters, search: e.target.value })}/></label><div className="filter-icon"><Filter size={15}/></div>
        <select aria-label="Minimum score" value={filters.minScore || 0} onChange={(e) => onFilters({ ...filters, minScore: Number(e.target.value) })}><option value="0">Any score</option><option value="80">80+</option><option value="90">90+</option><option value="95">95+</option></select>
        <select aria-label="Industry" value={filters.industry || "all"} onChange={(e) => onFilters({ ...filters, industry: e.target.value })}><option value="all">All industries</option>{industries.map((industry) => <option key={industry}>{industry}</option>)}</select>
        <select aria-label="PE backing" value={filters.peBacked || "all"} onChange={(e) => onFilters({ ...filters, peBacked: e.target.value as OpportunityFilters["peBacked"] })}><option value="all">Any ownership</option><option value="yes">PE-backed</option><option value="no">Not PE-backed</option></select>
        <select aria-label="Confidence" value={filters.confidence || "all"} onChange={(e) => onFilters({ ...filters, confidence: e.target.value })}><option value="all">Any confidence</option><option>High</option><option>Medium</option><option>Low</option></select>
        <select aria-label="Status" value={filters.status || "all"} onChange={(e) => onFilters({ ...filters, status: e.target.value })}><option value="all">Any status</option>{statuses.map((status) => <option key={status}>{status}</option>)}</select>
      </div>
      <div className="opportunity-table"><div className="table-head"><span>Company</span><span>Score</span><span>Trigger</span><span>Decision maker</span><span>Status</span><span /></div>{visible.map((item) => <button className="opportunity-row" key={item.id} onClick={() => onSelect(item.id)}><span className="company-cell"><i><Building2 size={16}/></i><b>{item.company}</b><small>{item.industry}</small></span><span><strong className={item.score >= 80 ? "pink" : ""}>{item.score}</strong><small>{item.confidence || "–"} confidence</small></span><span className="truncate">{item.trigger || "—"}</span><span><b>{item.contact?.name || "To validate"}</b><small>{item.contact?.role}</small></span><span><em>{item.status}</em></span><span><ArrowUpRight size={17}/></span></button>)}</div>
    </section>
  </div>;
}
