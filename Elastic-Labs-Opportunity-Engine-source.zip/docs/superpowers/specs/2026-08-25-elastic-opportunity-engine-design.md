# Elastic Labs Opportunity Engine — V1 Design

## Product outcome

Build Elastic Labs' internal commercial operating platform around one central object: the opportunity. A user starts with a ranked, evidence-backed company signal, deliberately generates an Outside-In, converts the resulting capability hypothesis into a Core / Flex / Scale strawman, models internal economics, and exports a client-safe document.

The daily decision surface answers two questions quickly: "Who appears to need Elastic Labs right now, and why?" and "If the hypothesis is correct, what capability could we put around the problem?"

## V1 boundary

V1 implements the complete human-approved path:

1. Import and rank opportunities from the existing Google Sheet through a swappable adapter, with a resilient seeded fallback.
2. Filter and inspect opportunity research, contacts, evidence, sources, facts, inferences, hypotheses, and critical unknowns.
3. Generate an Outside-In only after the user clicks Build Outside-In.
4. Edit, reorder, duplicate, remove, add, and autosize report sections.
5. Generate prospect-specific Core / Flex / Scale capability architecture with role-level justification.
6. Convert capability architecture into an editable commercial strawman without re-entry.
7. Calculate true buy, sell, GP, GM, markup, phases, scenarios, and commercial warnings.
8. Keep internal and client data separate through distinct typed serializers.
9. Export internal economics as CSV and client content as PDF and editable DOCX.
10. Create or update the exact native Google Doc through a server-side Google Drive adapter when credentials are configured, preserving the direct document URL.

Apollo, HubSpot, automated research agents, email sending, talent-network operations, and multi-user database persistence are extension seams, not V1 features. No output is sent automatically.

## Architecture

The application is a Next.js App Router TypeScript project deployed on Vercel. Domain logic is framework-independent and covered by unit tests. The UI is split into focused opportunity, Outside-In, capability, economics, and export modules. The initial persistence layer uses browser local storage for authored state while server routes supply live Sheet data and Google Drive operations.

External integrations sit behind interfaces:

- `OpportunitySource` normalises Sheet rows into domain opportunities and may later be replaced by a database or research API.
- `DocumentPublisher` accepts only the client-safe document model and may target Google Drive or a download exporter.
- The UI never passes full internal opportunity objects to client exporters.

## Data model

`Opportunity` contains company identity, score, confidence, trigger, research, evidence, contact, workflow status, optional Outside-In, capability architecture, strawman, and linked-document metadata. Missing source fields remain optional; the importer does not fabricate them.

`EvidenceItem` carries claim classification (`fact`, `evidence`, `inference`, `hypothesis`), source URL/title/date, summary, and confidence.

`OutsideIn` contains editable ordered blocks plus structured trigger, exposure, tension, capability hypothesis, critical unknown, and discovery question fields.

`CapabilityRole` belongs to Core, Flex, or Scale and includes role, seniority, capability, reason, ownership, entry timing, allocation, duration, engagement type, and optional flex trigger.

`CommercialRole` extends the capability role with benchmark rate, true-buy assumptions, buy, pricing mode, sell, GP, GM, and markup. Calculation functions remain pure.

## Opportunity flow

The Opportunities homepage defaults to descending score and visually prioritises scores of 80 or more. A focused "Today's Opportunities" treatment elevates the first three active qualified records. Filters support score, industry, trigger, PE backing, revenue, employees, confidence, and status.

Opening a record shows What happened, Why it might matter, Why Elastic, and What we do not know before supporting research. Claim labels are explicit and never collapsed into one generic narrative.

Build Outside-In is an intentional user action. It uses deterministic, trigger-aware templates in V1 so different opportunity types produce materially different hypotheses and capability shapes. The generation interface is isolated so an AI/research service can replace it later without changing the editor.

## Capability and commercial flow

Core contains the smallest credible 2–3 person starting team. Flex roles are temporary and include the evidence or delivery condition that triggers their use. Scale roles describe additional delivery capacity only after value is proven.

Turn Into Strawman maps these roles directly into the commercial model. Users may add, edit, duplicate, remove, reorder, and move roles between layers. Role calculations account for engagement-specific costs, allocation, duration, utilisation, and overhead. Margin and markup use distinct formulae:

- Gross margin = `(sell - buy) / sell`
- Markup = `(sell - buy) / buy`

The model supports target-margin, markup, and manual-sell pricing. A warning appears below the 35% target gross margin.

## Client safety boundary

The `toClientDocument()` function constructs a new, explicit allow-list model. It includes the problem, evidence, hypothesis, capability architecture, team shape, deployment, and sell-side investment. It cannot contain buy, GP, GM, markup, utilisation, bench, compensation, or internal assumptions because those fields do not exist in its return type.

PDF, DOCX, and Google Drive creation all consume this client-safe model. CSV consumes the internal economics model. Tests scan client exports and serialised payloads for forbidden internal terms and values.

## Google Docs route

The app's primary export action calls `/api/google-docs`. The route receives only a validated client-safe document, builds a DOCX-compatible payload, uploads it to Google Drive with conversion to native Google Docs, and returns the exact edit URL. If a linked file ID is supplied, it updates that file only after an explicit confirmation in the UI. Opening an already-linked document never overwrites edits.

Required Vercel secrets are `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, and `GOOGLE_REFRESH_TOKEN`. When absent, the UI explains that Google publishing is not configured and keeps Download editable DOCX available; it never falls back to `docs.new`.

## Visual system

Use Elastic Labs' warm off-white background, white paper surfaces, black editorial typography, restrained pink, subtle grey dividers, generous whitespace, and a quiet consulting-document feel. Avoid dark SaaS styling, gradients, excessive cards, recruitment conventions, and AI imagery.

The layout uses a compact left navigation, an editorial workspace, a persistent opportunity context header, readable tables, and responsive stacking. Textareas autosize to their full content and retain stable React keys so typing never loses focus.

## Error handling

Sheet fetch failure falls back to realistic seed records and visibly labels the source state. Invalid or missing Sheet cells remain undefined. Export failures return actionable messages and leave authored data untouched. Google Drive credentials and API errors are separated from document-generation errors.

## Verification

Automated tests cover Sheet mapping, sorting/filtering, Outside-In generation, materially different capability architectures, economics formulae, scenario totals, client safety, and export payloads. Browser checks cover the full Opportunity → Outside-In → Strawman → Export journey, stable typing focus, responsive layout, and error overlays. Production verification checks the live Vercel URL and runtime errors.
