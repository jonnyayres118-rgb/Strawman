import type { ClientDocument } from "@/lib/domain/types";
import { buildDocxBuffer, safeFilename } from "@/lib/exports/docx";

const forbidden = /^(buy|buyrate|truebuy|gp|grossprofit|grossmargin|markup|bench|utilisation|compensation|salarybenchmark|commercialassumptions)$/i;
export function validateClientPayload(payload: unknown): asserts payload is ClientDocument {
  if (!payload || typeof payload !== "object") throw new Error("A client-safe document is required.");
  const walk = (value: unknown) => { if (!value || typeof value !== "object") return; for (const [key, child] of Object.entries(value as Record<string, unknown>)) { if (forbidden.test(key.replace(/[^a-z]/gi, ""))) throw new Error(`Payload is not client-safe: ${key}`); walk(child); } }; walk(payload);
  const doc = payload as Partial<ClientDocument>; if (!doc.title || !doc.company || !Array.isArray(doc.sections) || !Array.isArray(doc.roles)) throw new Error("A complete client-safe document is required.");
}
export const googleDocEditUrl = (fileId: string) => `https://docs.google.com/document/d/${encodeURIComponent(fileId)}/edit`;

export async function getGoogleAccessToken(env: NodeJS.ProcessEnv, fetcher: typeof fetch): Promise<string> {
  const clientId = env.GOOGLE_CLIENT_ID; const clientSecret = env.GOOGLE_CLIENT_SECRET; const refreshToken = env.GOOGLE_REFRESH_TOKEN;
  if (!clientId || !clientSecret || !refreshToken) throw new Error("GOOGLE_NOT_CONFIGURED");
  const response = await fetcher("https://oauth2.googleapis.com/token", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: new URLSearchParams({ client_id: clientId, client_secret: clientSecret, refresh_token: refreshToken, grant_type: "refresh_token" }) });
  if (!response.ok) throw new Error(`Google authentication failed (${response.status})`); const data = await response.json() as { access_token?: string }; if (!data.access_token) throw new Error("Google authentication returned no access token"); return data.access_token;
}

export async function createGoogleDoc(document: ClientDocument, env: NodeJS.ProcessEnv = process.env, fetcher: typeof fetch = fetch) {
  validateClientPayload(document); const token = await getGoogleAccessToken(env, fetcher); const bytes = await buildDocxBuffer(document); const boundary = `elastic_${Date.now().toString(16)}`;
  const metadata = Buffer.from(JSON.stringify({ name: safeFilename(document.company).replace(/\.docx$/i, ""), mimeType: "application/vnd.google-apps.document" }));
  const body = Buffer.concat([Buffer.from(`--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n`), metadata, Buffer.from(`\r\n--${boundary}\r\nContent-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document\r\nContent-Disposition: attachment; filename="proposal.docx"\r\n\r\n`), bytes, Buffer.from(`\r\n--${boundary}--`)]);
  const response = await fetcher("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,mimeType,webViewLink", { method: "POST", headers: { Authorization: `Bearer ${token}`, "Content-Type": `multipart/related; boundary=${boundary}` }, body });
  if (!response.ok) throw new Error(`Google Drive upload failed (${response.status}): ${(await response.text()).slice(0, 180)}`); const result = await response.json() as { id?: string; webViewLink?: string }; if (!result.id) throw new Error("Google Drive returned no file ID"); return { fileId: result.id, url: result.webViewLink || googleDocEditUrl(result.id), updated: false };
}
