"use client";
import { forwardRef, useLayoutEffect, useRef } from "react";

export const AutosizeTextarea = forwardRef<HTMLTextAreaElement, React.TextareaHTMLAttributes<HTMLTextAreaElement>>(function AutosizeTextarea(props, forwardedRef) {
  const innerRef = useRef<HTMLTextAreaElement | null>(null);
  useLayoutEffect(() => { const node = innerRef.current; if (!node) return; node.style.height = "0px"; node.style.height = `${Math.max(92, node.scrollHeight)}px`; }, [props.value]);
  return <textarea {...props} ref={(node) => { innerRef.current = node; if (typeof forwardedRef === "function") forwardedRef(node); else if (forwardedRef) forwardedRef.current = node; }} />;
});
