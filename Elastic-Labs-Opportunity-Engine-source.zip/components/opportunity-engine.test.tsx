import { fireEvent, render, screen } from "@testing-library/react";
import { expect, it, vi } from "vitest";
import { OpportunityEngine } from "./opportunity-engine";
import { seedOpportunities } from "@/lib/data/seed-opportunities";

vi.stubGlobal("fetch", vi.fn(() => new Promise(() => undefined)));

it("moves deliberately from opportunity to Outside-In and strawman", () => {
  render(<OpportunityEngine initialOpportunities={seedOpportunities.slice(0, 2)} />);
  fireEvent.click(screen.getAllByText("Lawfront")[0]);
  expect(screen.getByText("What happened?", { selector: "h3" })).toBeInTheDocument();
  fireEvent.click(screen.getByRole("button", { name: /Build Outside-In/i }));
  expect(screen.getByText("Outside-In editor")).toBeInTheDocument();
  fireEvent.click(screen.getByRole("button", { name: /Turn into strawman/i }));
  expect(screen.getByText("Commercial strawman")).toBeInTheDocument();
});
