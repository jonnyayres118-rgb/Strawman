import { OpportunityEngine } from "@/components/opportunity-engine";
import { seedOpportunities } from "@/lib/data/seed-opportunities";

export default function Page() { return <OpportunityEngine initialOpportunities={seedOpportunities} />; }
