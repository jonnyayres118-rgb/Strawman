import type { Opportunity } from "./domain/types";

const KEY = "elastic-opportunity-engine-v1";
export function loadAuthoredState(): Record<string, Opportunity> { if (typeof window === "undefined") return {}; try { return JSON.parse(localStorage.getItem(KEY) || "{}"); } catch { return {}; } }
export function saveAuthoredState(opportunities: Opportunity[]) { if (typeof window !== "undefined") localStorage.setItem(KEY, JSON.stringify(Object.fromEntries(opportunities.map((item) => [item.id, item])))); }
export function mergeAuthoredState(fresh: Opportunity[], authored: Record<string, Opportunity>): Opportunity[] { return fresh.map((item) => authored[item.id] ? { ...item, ...authored[item.id], evidence: item.evidence?.length ? item.evidence : authored[item.id].evidence } : item); }
