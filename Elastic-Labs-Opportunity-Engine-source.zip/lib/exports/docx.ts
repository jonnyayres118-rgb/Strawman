import { AlignmentType, BorderStyle, Document, HeadingLevel, ImageRun, Packer, Paragraph, ShadingType, Table, TableCell, TableRow, TextRun, WidthType } from "docx";
import type { ClientDocument } from "@/lib/domain/types";

const dateStamp = () => new Date().toISOString().slice(0, 10);
export function safeFilename(company: string) { return `Elastic Labs – ${company.replace(/[\\/:*?"<>|]/g, "-")} – Outside-In – ${dateStamp()}.docx`; }
const pink = "FF336D"; const black = "171417"; const grey = "E8E5E0";
const sectionHeading = (text: string) => new Paragraph({ heading: HeadingLevel.HEADING_1, spacing: { before: 360, after: 160 }, border: { bottom: { color: black, style: BorderStyle.SINGLE, size: 12, space: 8 } }, children: [new TextRun({ text, bold: true, color: black, size: 34, font: "Arial" })] });
function imageFromDataUrl(url: string) { const match = url.match(/^data:image\/(png|jpe?g|gif|bmp);base64,(.+)$/); if (!match) return undefined; const raw = typeof atob === "function" ? Uint8Array.from(atob(match[2]), (character) => character.charCodeAt(0)) : Buffer.from(match[2], "base64"); const type = match[1] === "jpeg" ? "jpg" : match[1] as "png" | "jpg" | "gif" | "bmp"; return new ImageRun({ type, data: raw, transformation: { width: 620, height: 349 } }); }

export function createDocx(document: ClientDocument): Document {
  const children: Array<Paragraph | Table> = [
    new Paragraph({ spacing: { before: 500, after: 100 }, children: [new TextRun({ text: "ELASTIC LABS", bold: true, color: pink, size: 22, font: "Arial", characterSpacing: 180 })] }),
    new Paragraph({ spacing: { before: 1000, after: 180 }, children: [new TextRun({ text: document.title, bold: true, color: black, size: 56, font: "Arial" })] }),
    new Paragraph({ spacing: { after: 900 }, children: [new TextRun({ text: `${document.company}  ·  ${document.date}`, color: "666666", size: 24, font: "Arial" })] }),
  ];
  for (const section of document.sections) { children.push(sectionHeading(section.title)); const image = section.imageUrl ? imageFromDataUrl(section.imageUrl) : undefined; if (image) children.push(new Paragraph({ spacing: { after: 180 }, children: [image] })); children.push(...section.content.split(/\n{2,}/).map((text) => new Paragraph({ spacing: { after: 180 }, children: [new TextRun({ text, color: black, size: 22, font: "Arial" })] }))); }
  if (document.roles.length) {
    children.push(sectionHeading("Illustrative Core / Flex / Scale capability"));
    children.push(new Table({ width: { size: 100, type: WidthType.PERCENTAGE }, rows: [new TableRow({ tableHeader: true, children: ["Layer", "Role", "Capability", "Why included", "Enters"].map((text) => new TableCell({ shading: { type: ShadingType.CLEAR, fill: black }, children: [new Paragraph({ children: [new TextRun({ text, bold: true, color: "FFFFFF", size: 18 })] })] })) }), ...document.roles.map((role) => new TableRow({ children: [role.layer.toUpperCase(), `${role.role}\n${role.seniority}`, role.capability, role.reason, role.enters].map((text) => new TableCell({ borders: { top: { style: BorderStyle.SINGLE, color: grey, size: 4 }, bottom: { style: BorderStyle.SINGLE, color: grey, size: 4 }, left: { style: BorderStyle.SINGLE, color: grey, size: 4 }, right: { style: BorderStyle.SINGLE, color: grey, size: 4 } }, children: [new Paragraph({ children: [new TextRun({ text, size: 18, color: black })] })] })) }))] }));
  }
  if (document.investment) { children.push(sectionHeading("Indicative investment"), new Paragraph({ alignment: AlignmentType.LEFT, children: [new TextRun({ text: `${new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP", maximumFractionDigits: 0 }).format(document.investment.monthly)} per month`, bold: true, color: pink, size: 36 }), new TextRun({ text: `\n${new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP", maximumFractionDigits: 0 }).format(document.investment.total)} across the illustrative ${document.investment.durationMonths}-month deployment`, color: black, size: 22 })] })); }
  children.push(new Paragraph({ spacing: { before: 600 }, border: { top: { style: BorderStyle.SINGLE, color: grey, size: 4, space: 8 } }, children: [new TextRun({ text: "Confidential · Prepared by Elastic Labs · elastic-labs.com", color: "777777", size: 16 })] }));
  return new Document({ styles: { default: { document: { run: { font: "Arial", size: 22, color: black }, paragraph: { spacing: { line: 300 } } } } }, sections: [{ properties: { page: { margin: { top: 1000, right: 1000, bottom: 1000, left: 1000 } } }, children }] });
}

export async function buildDocxBlob(document: ClientDocument): Promise<Blob> { return Packer.toBlob(createDocx(document)); }
export async function buildDocxBuffer(document: ClientDocument): Promise<Buffer> { return Packer.toBuffer(createDocx(document)); }
