import { benchmarkFor } from "@/lib/data/benchmarks";
import type { CapabilityArchitecture, CapabilityLayer, CapabilityRole, CommercialRole, Opportunity, OutsideIn } from "./types";

let roleSequence = 0;
function role(layer: CapabilityLayer, title: string, capability: string, reason: string, owns: string, enters: string, flexTrigger?: string, seniority = "Senior"): CapabilityRole {
  return { id: `role-${(roleSequence += 1).toString(36)}`, layer, role: title, seniority, capability, reason, owns, enters, allocation: layer === "flex" ? 0.5 : 1, durationMonths: layer === "scale" ? 3 : 6, engagementType: "contractor", flexTrigger };
}

export function buildCapabilityArchitecture(opportunity: Opportunity, outsideIn?: OutsideIn): CapabilityArchitecture {
  const signal = [opportunity.industry, opportunity.trigger, outsideIn?.capabilityHypothesis].filter(Boolean).join(" ").toLowerCase();
  let core: CapabilityRole[]; let flex: CapabilityRole[]; let scale: CapabilityRole[];
  if (/health|patient|clinical|fertility/.test(signal)) {
    core = [role("core", "Digital Product Lead", "Regulated product delivery", "Frames one valuable, safe patient or operational outcome.", "Outcome, roadmap and clinical stakeholder alignment", "Phase 1", undefined, "Principal"), role("core", "Clinical Data Engineer", "Secure clinical data foundations", "Tests whether the priority can be delivered with trusted, governed data.", "Data model, integration and quality", "Phase 1"), role("core", "Platform Engineer", "Reliable platform delivery", "Turns the proof into a secure working service.", "Application architecture and delivery", "Phase 1")];
    flex = [role("flex", "Security Architect", "Privacy and security", "Adds assurance without holding the role permanently.", "Threat model and controls", "When sensitive data boundaries are confirmed", "The proof touches patient-identifiable or cross-market data", "Principal"), role("flex", "Product Designer", "Patient and colleague experience", "Introduces research and service design where workflow risk warrants it.", "Journey validation", "When user behaviour becomes the constraint", "Discovery exposes a high-friction patient or clinic journey")];
    scale = [role("scale", "Clinical Data Engineer", "Scaled data delivery", "Adds delivery throughput only after the data pattern is proven.", "Additional sources and markets", "Phase 3"), role("scale", "Change & Adoption Lead", "Adoption", "Industrialises new workflows across clinics.", "Rollout and adoption", "Phase 3")];
  } else if (/acquisition|merger|consolidat|integration/.test(signal)) {
    core = [role("core", "Platform Integration Lead", "Integration architecture", "Creates a repeatable integration path across acquired businesses.", "Target architecture and integration decisions", "Phase 1", undefined, "Principal"), role("core", "Data Engineer", "Data integration", "Makes fragmented operational data usable and comparable.", "Data mapping, pipelines and quality", "Phase 1"), role("core", "Product Manager", "Transformation product leadership", "Prioritises the integration work that changes operations first.", "Outcome, backlog and stakeholder alignment", "Phase 1")];
    flex = [role("flex", "Cloud / DevOps Engineer", "Platform deployment", "Adds specialist infrastructure capability for environments and release paths.", "Cloud foundations and CI/CD", "When target platforms are selected", "Discovery confirms inconsistent cloud, identity or deployment patterns"), role("flex", "Security Architect", "Security", "Addresses inherited controls and access risk during integration.", "Security architecture", "When system boundaries are mapped", "Acquired systems create material identity, data or compliance exposure", "Principal")];
    scale = [role("scale", "Data Engineer", "Scaled integration delivery", "Runs multiple prioritised data integrations in parallel.", "Additional integration streams", "Phase 3"), role("scale", "Platform Engineer", "Reusable integration platform", "Turns successful patterns into a repeatable group capability.", "Shared services and tooling", "Phase 3")];
  } else if (/ai|automation|machine learning/.test(signal)) {
    core = [role("core", "AI Product Lead", "AI product delivery", "Keeps the work anchored to an operational outcome rather than a model demo.", "Problem framing, roadmap and value proof", "Phase 1", undefined, "Principal"), role("core", "AI Engineer", "Applied AI engineering", "Builds and tests the smallest production-credible solution.", "Application, evaluation and guardrails", "Phase 1"), role("core", "Data Engineer", "AI-ready data", "Ensures the proof uses governed, reliable data.", "Pipelines, retrieval and quality", "Phase 1")];
    flex = [role("flex", "MLOps Engineer", "AI infrastructure", "Adds production operations only when the proof needs to run reliably at scale.", "Deployment, observability and model operations", "Phase 2", "A successful proof needs production reliability or model lifecycle management"), role("flex", "Product Designer", "Human-AI interaction", "Tests whether the workflow is usable and trusted.", "Interaction design and research", "When adoption risk becomes visible", "The value depends on a new human decision or behaviour")];
    scale = [role("scale", "AI Engineer", "Scaled AI delivery", "Adds delivery capacity only after the first use case proves value.", "Additional use cases", "Phase 3"), role("scale", "Cloud / DevOps Engineer", "Platform scale", "Hardens common infrastructure for repeatable delivery.", "Platform reliability", "Phase 3")];
  } else {
    core = [role("core", "Product Lead", "Product leadership", "Defines the operational problem and proof boundary.", "Outcomes and roadmap", "Phase 1", undefined, "Principal"), role("core", "Automation Engineer", "Operational automation", "Builds the smallest credible intervention around the workflow.", "Automation and integration", "Phase 1")];
    flex = [role("flex", "Data Engineer", "Data foundations", "Joins only when source quality or integration becomes a constraint.", "Pipelines and quality", "Phase 2", "Discovery shows fragmented or unreliable operational data")];
    scale = [role("scale", "Automation Engineer", "Scaled delivery", "Adds throughput after a repeatable pattern is proven.", "Additional workflows", "Phase 3")];
  }
  return { framing: "If the hypothesis is directionally correct, an illustrative capability model could look like this.", core, flex, scale };
}

export function toCommercialRoles(architecture: CapabilityArchitecture): CommercialRole[] {
  return [...architecture.core, ...architecture.flex, ...architecture.scale].map((item) => {
    const benchmarkRate = benchmarkFor(item.role, item.seniority);
    return { ...item, benchmarkRate, buyRate: benchmarkRate, pricingMode: "target-margin", targetMargin: 0.4 };
  });
}
